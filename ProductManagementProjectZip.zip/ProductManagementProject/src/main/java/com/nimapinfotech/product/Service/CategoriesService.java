package com.nimapinfotech.product.Service;

import org.springframework.stereotype.Component;

import com.nimapinfotech.product.Entity.Category;

@Component
public interface CategoriesService {
	
	public boolean saveCategory(Category category);
	
	public Category getCategoryWiseProducts(int categoryId);
	
	public boolean updateCategoryById(Category category);
	
	public boolean deleteCategoryById(int categoryId);
}
