package com.nimapinfotech.product.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimapinfotech.product.Entity.Product;
import com.nimapinfotech.product.Repository.ProductDaoImpl;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDaoImpl dao;
	
	@Override
	public boolean saveProduct(Product product) {
		return dao.saveProduct(product);
	}

	@Override
	public boolean updateProduct(Product product) {
		return dao.updateProduct(product);
	}

	@Override
	public boolean deleteProductById(int productId) {
		return dao.deleteProductById(productId);
	}
	
	

}
