package com.nimapinfotech.product.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nimapinfotech.product.Entity.Category;
import com.nimapinfotech.product.Service.CategoriesServiceImpl;

@RestController
public class CategoryController {

	@Autowired
	private CategoriesServiceImpl service;
	
	@RequestMapping(value="/saveCategory",method = RequestMethod.POST)
	@ResponseBody
	public boolean saveCategory(@RequestBody Category category) {
		return service.saveCategory(category);
	}
	
	@RequestMapping(value="getCategoryWiseProducts/{categoryId}",method = RequestMethod.GET)
	public Category getCategoryWiseProducts(@PathVariable int categoryId) {
		return service.getCategoryWiseProducts(categoryId);
	}
	
	@RequestMapping(value="/updateCategory",method = RequestMethod.PUT)
	@ResponseBody
	public boolean updateCategoryById(@RequestBody Category category) {
		return service.updateCategoryById(category);
	}
	
	@RequestMapping(value="/deleteCategoryById/{categoryId}",method = RequestMethod.DELETE)
	public boolean deleteCategoryById(@PathVariable int categoryId) {
		return service.deleteCategoryById(categoryId);
	}
}
