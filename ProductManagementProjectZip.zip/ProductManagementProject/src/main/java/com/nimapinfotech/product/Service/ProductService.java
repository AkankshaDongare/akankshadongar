package com.nimapinfotech.product.Service;

import com.nimapinfotech.product.Entity.Product;

public interface ProductService {

	public boolean saveProduct(Product product);
	
	public boolean updateProduct(Product product);
	
	public boolean deleteProductById(int productId);
}

