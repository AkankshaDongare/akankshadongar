package com.nimapinfotech.product.Repository;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nimapinfotech.product.Entity.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	SessionFactory factory;

	@Override
	public boolean saveProduct(Product product) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Product product1 = null;
		boolean isSaved = false;

		try {
			product1 = session.get(Product.class, product.getProductId());
			if (product1 == null) {
				session.save(product);
				transaction.commit();
				isSaved = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSaved;
	}

	@Override
	public boolean updateProduct(Product product) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Product product1 = null;
		boolean isUpdated = false;
		try {
			product1 = session.get(Product.class, product.getProductId());
			if (product1 != null) {
				product1.setProductName(product.getProductName());
				product1.setProductPrice(product.getProductPrice());
				// product1.setCategory(product.getCategory());
				session.update(product1);
				isUpdated = true;
				transaction.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isUpdated;
	}

	@Override
	public boolean deleteProductById(int productId) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Product product1 = null;
		boolean isDeleted = false;
		try {
			product1=session.get(Product.class, productId);
			if(product1 != null) {
				session.delete(product1);
				transaction.commit();
				isDeleted=true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

}
