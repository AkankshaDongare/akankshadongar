package com.nimapinfotech.product.Repository;

import com.nimapinfotech.product.Entity.Category;

public interface CategoriesDao {

	public boolean saveCategory(Category category);
	
	public Category getCategoryWiseProducts(int categoryId);
	
	public boolean updateCategoryById(Category category);
	
	public boolean deleteCategoryById(int categoryId);
}
