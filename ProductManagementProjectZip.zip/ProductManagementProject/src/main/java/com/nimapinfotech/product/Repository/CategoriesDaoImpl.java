package com.nimapinfotech.product.Repository;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nimapinfotech.product.Entity.Category;

@Repository
public class CategoriesDaoImpl implements CategoriesDao {

	@Autowired
	SessionFactory factory;

	@Override
	public boolean saveCategory(Category category) {

		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		boolean isSaved = false;
		Category category1=null;
		System.out.println(category);
		try {
			category1=session.get(Category.class,category.getCategoryId());
			if (category1 == null) {
				session.save(category);
				transaction.commit();
				isSaved = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isSaved;
	}

	@Override
	public Category getCategoryWiseProducts(int categoryId) {
		Session session = factory.openSession();
		Category category = null;
		try {
			category = session.get(Category.class, categoryId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return category;
	}

	@Override
	public boolean updateCategoryById(Category category) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Category category1 = null;
		boolean isUpdated = false;
		try {
			category1 = session.get(Category.class, category.getCategoryId());
			if (category1 != null) {
				category1.setProductType(category.getProductType());
				category1.setProducts(category.getProducts());
				// category1.setProducts(category.getProducts());
				session.update(category1);
				isUpdated = true;
				transaction.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isUpdated;
	}

	@Override
	public boolean deleteCategoryById(int categoryId) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Category category1 = null;
		boolean isDeleted = false;

		try {
			category1 = session.get(Category.class, categoryId);
			if (category1 != null) {
				session.delete(category1);
				isDeleted = true;
				transaction.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

}
