package com.nimapinfotech.product.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.nimapinfotech.product.Entity.Category;
import com.nimapinfotech.product.Entity.Product;
import com.nimapinfotech.product.Service.ProductServiceImpl;

@RestController
public class ProductController {
	
	@Autowired
	SessionFactory factory;
	
	@Autowired
	ProductServiceImpl service;
	
	@RequestMapping(value="/saveProduct",method = RequestMethod.POST)
	@ResponseBody
	public boolean saveProduct(@RequestBody Product product) {
		return service.saveProduct(product);
	}
	
	@RequestMapping(value="/updateProduct",method = RequestMethod.PUT)
	@ResponseBody
	public boolean updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}
	
	@RequestMapping(value="/deleteProduct/{productId}",method = RequestMethod.DELETE)
	@ResponseBody
	public boolean deleteProductById(@PathVariable int productId) {
		return service.deleteProductById(productId);
	}
}
