package com.nimapinfotech.product.Repository;

import com.nimapinfotech.product.Entity.Product;

public interface ProductDao {

	public boolean saveProduct(Product product);
	
	public boolean updateProduct(Product product);
	
	public boolean deleteProductById(int productId);
}
