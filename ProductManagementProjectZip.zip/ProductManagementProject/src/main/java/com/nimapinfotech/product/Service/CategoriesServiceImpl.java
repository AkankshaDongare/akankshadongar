package com.nimapinfotech.product.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimapinfotech.product.Entity.Category;
import com.nimapinfotech.product.Repository.CategoriesDaoImpl;

@Service
public class CategoriesServiceImpl implements CategoriesService {
	
	@Autowired
	private CategoriesDaoImpl dao;

	@Override
	public boolean saveCategory(Category category) {

		return dao.saveCategory(category);
	}

	@Override
	public Category getCategoryWiseProducts(int categoryId) {
		return dao.getCategoryWiseProducts(categoryId);
	}

	@Override
	public boolean updateCategoryById(Category category) {
		return dao.updateCategoryById(category);
	}

	@Override
	public boolean deleteCategoryById(int categoryId) {
		return dao.deleteCategoryById(categoryId);
	}

}
