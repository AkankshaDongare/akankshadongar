package com.nimapinfotech.product.Entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Category {

	@Id
	int categoryId;

	String productType;

	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "catgeory")
	@JoinColumn(name = "category_Id",referencedColumnName="categoryId")
	@JsonIgnoreProperties("category")
	List<Product> products = new ArrayList<>();

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", productType=" + productType + ", products=" + products + "]";
	}

	public Category(int categoryId, String productType, List<Product> products) {
		super();
		this.categoryId = categoryId;
		this.productType = productType;
		this.products = products;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Category() {
		// TODO Auto-generated constructor stub
	}

}
